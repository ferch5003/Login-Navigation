import 'package:flutter/material.dart';
import 'package:login_navigation/screens/screen.dart';

void main() => runApp(Screen());
